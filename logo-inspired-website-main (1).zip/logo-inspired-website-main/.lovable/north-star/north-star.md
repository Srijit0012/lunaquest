<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Players learn what it takes to keep a crew alive on the Moon or Mars.

## Metric

Missions played through to a win or loss each week
