import { describe, expect, it } from 'vitest';
import { initialMotion, INTERACTION_POINTS, selectTarget, stepMotion } from '@/scene/astronaut-motion';
describe('Infrastructure inspection', () => {
  it('approaches greenhouse and completes inspection without changing mission state', () => {
    const s = selectTarget(initialMotion(), 'greenhouse');
    for (let i = 0; i < 2000; i++) stepMotion(s, .05);
    expect([s.x, s.z]).toEqual(INTERACTION_POINTS.greenhouse); expect(s.phase).toBe('idle');
  });
  it('interrupts previous inspection with the latest selected facility', () => {
    let s = selectTarget(initialMotion(), 'solar'); stepMotion(s, .5); s = selectTarget(s, 'oxygen');
    for (let i = 0; i < 2000; i++) stepMotion(s, .05);
    expect(s.target).toBe('oxygen'); expect([s.x, s.z]).toEqual([9, 0]); expect(s.phase).toBe('idle');
  });
});
