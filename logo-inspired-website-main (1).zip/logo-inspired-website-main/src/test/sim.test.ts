import { describe, expect, it } from "vitest";
import { build, newGame, nextSol } from "@/lib/sim";

describe("simulation", () => {
  it("building spends materials", () => {
    const s = build(newGame("moon"), "solar");
    expect(s.res.materials).toBe(90);
    expect(s.buildings.solar).toBe(1);
  });
  it("cannot build without enough materials", () => {
    const s = newGame("moon");
    s.res.materials = 10;
    expect(build(s, "solar")).toBe(s);
  });
  it("crew consumes oxygen each sol", () => {
    const s = nextSol(newGame("moon"), () => 0.9);
    expect(s.res.oxygen).toBe(54);
    expect(s.sol).toBe(2);
  });
});
