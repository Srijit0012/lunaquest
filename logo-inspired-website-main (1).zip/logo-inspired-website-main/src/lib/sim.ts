export type MissionId = "moon" | "mars";
export type Resources = { power: number; oxygen: number; water: number; food: number; materials: number };
export type BuildingId = "solar" | "oxygen" | "water" | "greenhouse" | "shield" | "mine";

export const MISSIONS: Record<MissionId, {
  id: MissionId; name: string; difficulty: string; days: number; desc: string;
  traits: string[]; start: Resources; briefing: string[];
}> = {
  moon: {
    id: "moon", name: "MOON MISSION", difficulty: "Medium", days: 30,
    desc: "Establish a sustainable research outpost on the lunar surface.",
    traits: ["Lower gravity (1/6 g)", "Extreme temperature swings", "No breathable atmosphere", "Lunar regolith", "Long periods of darkness"],
    start: { power: 60, oxygen: 60, water: 50, food: 50, materials: 120 },
    briefing: [
      "Your crew of 4 has landed near the lunar south pole.",
      "Build solar arrays for power, then oxygen and water systems to keep the crew alive.",
      "Watch out for solar flares and meteorite strikes.",
      "Survive 30 sols to complete the mission.",
    ],
  },
  mars: {
    id: "mars", name: "MARS MISSION", difficulty: "Hard", days: 45,
    desc: "Grow a self-sufficient colony on the red planet.",
    traits: ["Thin CO₂ atmosphere", "Dust storms", "Lower gravity (0.38 g)", "Water ice resources", "Far from Earth"],
    start: { power: 50, oxygen: 50, water: 40, food: 45, materials: 110 },
    briefing: [
      "Your crew of 4 has touched down in Jezero Crater.",
      "Mine water ice, split it into oxygen, and grow food in greenhouses.",
      "Dust storms will cut your solar power — plan reserves.",
      "Survive 45 sols to complete the mission.",
    ],
  },
};

export const BUILDINGS: Record<BuildingId, { name: string; cost: number; desc: string; power: number; effect: Partial<Resources> }> = {
  solar: { name: "Solar Array", cost: 30, desc: "+12 power / sol", power: 12, effect: {} },
  oxygen: { name: "Oxygen Generator", cost: 35, desc: "+8 oxygen / sol, uses 4 power", power: -4, effect: { oxygen: 8 } },
  water: { name: "Ice Extractor", cost: 30, desc: "+7 water / sol, uses 3 power", power: -3, effect: { water: 7 } },
  greenhouse: { name: "Greenhouse", cost: 40, desc: "+7 food / sol, uses 3 power & 2 water", power: -3, effect: { food: 7, water: -2 } },
  mine: { name: "Regolith Mine", cost: 25, desc: "+10 materials / sol, uses 2 power", power: -2, effect: { materials: 10 } },
  shield: { name: "Radiation Shield", cost: 50, desc: "Protects crew health from flares", power: -1, effect: {} },
};

// Per-sol needs of a 4-person crew (educational approximation).
export const CREW_NEEDS = { oxygen: 6, water: 5, food: 5, power: 4 };

export type GameState = {
  mission: MissionId; sol: number; res: Resources; health: number;
  buildings: Record<BuildingId, number>; log: string[]; status: "playing" | "won" | "lost";
};

export function newGame(mission: MissionId): GameState {
  return {
    mission, sol: 1, res: { ...MISSIONS[mission].start }, health: 100,
    buildings: { solar: 0, oxygen: 0, water: 0, greenhouse: 0, mine: 0, shield: 0 },
    log: ["Sol 1: Landing successful. Build your base!"], status: "playing",
  };
}

export function build(s: GameState, id: BuildingId): GameState {
  const b = BUILDINGS[id];
  if (s.status !== "playing" || s.res.materials < b.cost) return s;
  return {
    ...s, res: { ...s.res, materials: s.res.materials - b.cost },
    buildings: { ...s.buildings, [id]: s.buildings[id] + 1 },
    log: [`Sol ${s.sol}: Built ${b.name}.`, ...s.log],
  };
}

const clamp = (n: number) => Math.max(0, Math.round(n));

export function nextSol(s: GameState, rand: () => number = Math.random): GameState {
  if (s.status !== "playing") return s;
  const r = { ...s.res };
  const log: string[] = [];
  let health = s.health;

  // Random event
  const roll = rand();
  let powerFactor = 1;
  if (roll < 0.15) {
    if (s.mission === "mars") { powerFactor = 0.4; log.push("Dust storm! Solar output drops sharply."); }
    else { powerFactor = 0.5; log.push("Lunar night — solar output reduced."); }
  } else if (roll < 0.25) {
    if (s.buildings.shield > 0) log.push("Solar flare blocked by radiation shield.");
    else { health -= 15; log.push("Solar flare! Crew exposed to radiation (−15 health)."); }
  } else if (roll < 0.32) {
    r.materials -= 15; log.push("Meteorite strike damaged supplies (−15 materials).");
  }

  // Power balance
  let power = s.buildings.solar * BUILDINGS.solar.power * powerFactor - CREW_NEEDS.power;
  const ids = Object.keys(BUILDINGS) as BuildingId[];
  for (const id of ids) if (id !== "solar") power += BUILDINGS[id].power * s.buildings[id];
  r.power += power;
  const powered = r.power > 0;
  if (!powered) log.push("Power shortage! Facilities offline.");

  // Production (only when powered)
  if (powered) for (const id of ids) {
    const eff = BUILDINGS[id].effect;
    for (const k of Object.keys(eff) as (keyof Resources)[]) r[k] += (eff[k] ?? 0) * s.buildings[id];
  }

  // Crew consumption
  r.oxygen -= CREW_NEEDS.oxygen; r.water -= CREW_NEEDS.water; r.food -= CREW_NEEDS.food;
  for (const k of ["oxygen", "water", "food"] as const) {
    if (r[k] < 0) { health -= 20; log.push(`Out of ${k}! Crew health −20.`); }
  }
  if (health > 0 && r.oxygen > 0 && r.water > 0 && r.food > 0) health = Math.min(100, health + 2);

  if (log.length === 0) log.push("All systems nominal.");
  const res = { power: clamp(r.power), oxygen: clamp(r.oxygen), water: clamp(r.water), food: clamp(r.food), materials: clamp(r.materials) };
  const sol = s.sol + 1;
  let status: GameState["status"] = "playing";
  if (health <= 0) { status = "lost"; log.push("Mission failed: the crew could not survive."); }
  else if (sol > MISSIONS[s.mission].days) { status = "won"; log.push("Mission complete! Your settlement survived."); }

  return { ...s, sol, res, health: Math.max(0, health), status, log: [...log.reverse().map((l) => `Sol ${s.sol}: ${l}`), ...s.log].slice(0, 40) };
}
