import { Component, Suspense, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Lightformer, OrbitControls, Stars, useGLTF } from '@react-three/drei';
import { EffectComposer, N8AO } from '@react-three/postprocessing';
import * as THREE from 'three';
import type { BuildingId, MissionId } from '@/lib/sim';
import { Terrain } from './terrain';
import { STRUCTURE_INFO, Structure, type StructureInfo } from './structures';
import { Earth, Sun, SUN_LIGHT } from './celestial';
import { PLANET_RADIUS } from './terrain';
import { ColonySupport } from './engineering';
import { GRAPHICS, scenePalette, type GraphicsQuality } from './palette';
import { Astronaut } from './Astronaut';
import type { InteractionTarget } from './astronaut-motion';

function ReadySignal() {
  const fired = useRef(false);
  useFrame(() => {
    if (!fired.current) { fired.current = true; document.querySelector('[data-planet-scene]')?.setAttribute('data-scene-ready', 'true'); }
  });
  return null;
}

class SceneBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  override render() {
    return this.state.failed ? <div role="alert" className="flex h-full items-center justify-center bg-card p-6 text-center text-muted-foreground">3D view unavailable on this device. Mission controls remain available below.</div> : this.props.children;
  }
}

export function PlanetScene({ mission, buildings, onHoverInfo, quality = 'balanced', cameraMode = 'colony', interaction = null }: {
  mission: MissionId; buildings: Record<BuildingId, number>; onHoverInfo: (info: StructureInfo | null) => void;
  quality?: GraphicsQuality; cameraMode?: 'colony' | 'astronaut';
  interaction?: { target: InteractionTarget; nonce: number } | null;
}) {
  const [hovered, setHovered] = useState<BuildingId | 'pad' | null>(null);
  const p = useMemo(scenePalette, []);
  const moon = mission === 'moon', settings = GRAPHICS[quality];
  const handleHover = (id: BuildingId | 'pad' | null) => { setHovered(id); onHoverInfo(id === null ? null : STRUCTURE_INFO[id]); };
  useEffect(() => () => { document.body.style.cursor = 'auto'; }, []);
  return <SceneBoundary><Canvas
    shadows={{ type: THREE.PCFShadowMap }} camera={{ position: [23, 12, 28], fov: 46, near: .1, far: 1200 }}
    dpr={[1, settings.dpr]} gl={{ antialias: quality !== 'low', powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping }}
    onPointerMissed={() => handleHover(null)} fallback={<div className="p-6 text-muted-foreground">3D graphics unavailable. Mission controls remain available below.</div>}
  >
    <color attach="background" args={[moon ? p.black : p.sky]} />
    {!moon && <fog attach="fog" args={[p.sky, 70, 330]} />}
    <ambientLight intensity={moon ? .3 : .45} color={moon ? p.glass : p.warm} />
    <directionalLight position={SUN_LIGHT} intensity={3.2} color={p.sun} castShadow
      shadow-mapSize={[settings.shadows, settings.shadows]} shadow-camera-left={-28} shadow-camera-right={28}
      shadow-camera-top={28} shadow-camera-bottom={-28} shadow-camera-near={1} shadow-camera-far={120}
      shadow-normalBias={.045} shadow-bias={-.00015} shadow-radius={moon ? 2 : 4} />
    {moon && <Stars radius={600} depth={30} count={1100} factor={1.2} saturation={0} />}
    <Sun />
    <Environment resolution={64}>
      <Lightformer intensity={1.3} position={[0, 12, 0]} rotation-x={Math.PI / 2} scale={[30, 30, 1]} color={moon ? p.glass : p.warm} />
      <Lightformer intensity={2} position={[-15, 6, -12]} scale={[12, 6, 1]} color={p.sun} />
      <Lightformer intensity={.4} position={[8, 3, 6]} scale={[16, 5, 1]} color={p.hull} />
    </Environment>
    <SkyDome moon={moon} sky={p.sky} />
    {/* Planet body continues the curved horizon beyond the local terrain. */}
    <mesh position={[0, -PLANET_RADIUS - 2.5, 0]} receiveShadow><sphereGeometry args={[PLANET_RADIUS, 160, 96]} /><meshStandardMaterial color={moon ? p.moon : p.mars} roughness={1} /></mesh>
    <Suspense fallback={null}><Terrain mission={mission} quality={quality} /></Suspense>
    <Suspense fallback={null}><Earth distant={!moon} /></Suspense>
    <Suspense fallback={null}><Astronaut interaction={interaction} /><ReadySignal /></Suspense>
    <ColonySupport />
    <Structure id="pad" count={1} hovered={hovered === 'pad'} onHover={handleHover} />
    {Object.keys(buildings).map(key => {
      const id = key as BuildingId;
      return <Structure key={id} id={id} count={buildings[id]} hovered={hovered === id} onHover={handleHover} />;
    })}
    <CameraRig mode={cameraMode} mission={mission} />
    {settings.ao && <EffectComposer enableNormalPass={false} multisampling={0}><N8AO aoRadius={.65} intensity={1.4} distanceFalloff={1} quality="medium" /></EffectComposer>}
  </Canvas></SceneBoundary>;
}

function SkyDome({ moon, sky }: { moon: boolean; sky: string }) {
  const material = useMemo(() => new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { horizon: { value: new THREE.Color(moon ? '#0b0d12' : sky) }, zenith: { value: new THREE.Color(moon ? '#000000' : sky).multiplyScalar(moon ? 1 : .42) } },
    vertexShader: 'varying vec3 d; void main(){ d = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }',
    fragmentShader: 'uniform vec3 horizon; uniform vec3 zenith; varying vec3 d; void main(){ float t = smoothstep(-.05, .6, d.y); gl_FragColor = vec4(mix(horizon, zenith, t), 1.); }',
  }), [moon, sky]);
  return <mesh material={material} renderOrder={-1}><sphereGeometry args={[900, 64, 32]} /></mesh>;
}

function CameraRig({ mode, mission }: { mode: 'colony' | 'astronaut'; mission: MissionId }) {
  const ref = useRef<React.ComponentRef<typeof OrbitControls>>(null);
  const transition = useRef(true);
  useEffect(() => { transition.current = true; }, [mode, mission]);
  useFrame(({ camera }, dt) => {
    if (!transition.current || !ref.current) return;
    const position = mode === 'astronaut' ? new THREE.Vector3(8, 3.2, 8) : new THREE.Vector3(23, 12, 28);
    const target = mode === 'astronaut' ? new THREE.Vector3(4.5, 1, 3.5) : new THREE.Vector3(0, 6, 0);
    const step = 1 - Math.exp(-Math.min(dt, .05) * 5);
    camera.position.lerp(position, step); ref.current.target.lerp(target, step); ref.current.update();
    if (camera.position.distanceTo(position) < .06) transition.current = false;
  });
  return <OrbitControls ref={ref} makeDefault enablePan={false} minDistance={4} maxDistance={58} minPolarAngle={.35} maxPolarAngle={Math.PI / 2.25} enableDamping dampingFactor={.09} onStart={() => { transition.current = false; }} />;
}
