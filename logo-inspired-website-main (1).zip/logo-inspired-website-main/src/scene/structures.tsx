import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { BuildingId } from "@/lib/sim";
import { scenePalette } from "./palette";

export type StructureInfo = {
  id: BuildingId | "pad";
  name: string;
  purpose: string;
  fact: string;
};

export const STRUCTURE_INFO: Record<BuildingId | "pad", StructureInfo> = {
  solar: {
    id: "solar",
    name: "Solar Array",
    purpose:
      "Converts sunlight into electrical energy to power habitats, laboratories, communication equipment and life-support systems.",
    fact: "A lunar day lasts about 14 Earth days, so Moon bases need big battery reserves to survive the long night.",
  },
  oxygen: {
    id: "oxygen",
    name: "Oxygen Generator",
    purpose:
      "Produces breathable oxygen by splitting water or extracting it from oxygen-rich regolith, keeping the crew alive.",
    fact: "Lunar and Martian soil is roughly 40–45% oxygen by weight — locked inside minerals.",
  },
  water: {
    id: "water",
    name: "Ice Extraction Facility",
    purpose:
      "Drills into the subsurface to mine water ice for drinking, growing food, making oxygen and even rocket fuel.",
    fact: "Permanently shadowed craters near the lunar south pole hold water ice that is billions of years old.",
  },
  greenhouse: {
    id: "greenhouse",
    name: "Greenhouse",
    purpose:
      "A pressurised dome where crops grow under controlled light, turning CO₂ into fresh food and recycling air and water.",
    fact: "Astronauts on the ISS have already grown and eaten lettuce, chillies and tomatoes in space.",
  },
  mine: {
    id: "mine",
    name: "Regolith Mine",
    purpose:
      "Excavates surface soil (regolith) to supply raw building materials for construction, repairs and manufacturing.",
    fact: "Regolith can be sintered into bricks — future bases may be 3D-printed from local soil.",
  },
  shield: {
    id: "shield",
    name: "Radiation Shield",
    purpose:
      "Layers of protective material that absorb cosmic rays and solar flare radiation before they reach the crew.",
    fact: "Without Earth's magnetic field, a strong solar storm can deliver a dangerous radiation dose in hours.",
  },
  pad: {
    id: "pad",
    name: "Landing Pad",
    purpose:
      "A reinforced platform where supply landers and crew vehicles touch down and lift off safely.",
    fact: "Rocket exhaust blasts regolith at high speed — pads protect both the ship and the base from flying debris.",
  },
};

// Fixed slots so structures never overlap; extra units of a type fan out in a row.
export const SLOTS: Record<BuildingId | "pad", [number, number]> = {
  pad: [0, 9],
  solar: [-11, -6],
  oxygen: [9, -3],
  water: [-9, 5],
  greenhouse: [2, -9],
  mine: [12, 6],
  shield: [-2, -1],
};

const MAX_VISIBLE = 4;

function unitOffsets(count: number): [number, number][] {
  const n = Math.min(count, MAX_VISIBLE);
  return Array.from({ length: n }, (_, i) => [(i % 2) * 3.2, Math.floor(i / 2) * 3.2] as [number, number]);
}

type ModelProps = { hovered: boolean };

function useMats(hovered: boolean) {
  const p = useMemo(scenePalette, []);
  // Shared material palette; emissive lifts when hovered.
  return {
    hull: <meshStandardMaterial color={p.hull} roughness={0.5} metalness={0.4} emissive={hovered ? p.selection : p.black} emissiveIntensity={hovered ? 0.25 : 0} />,
    dark: <meshStandardMaterial color={p.dark} roughness={0.7} metalness={0.3} />,
    accent: <meshStandardMaterial color={p.accent} roughness={0.5} metalness={0.2} emissive={hovered ? p.accent : p.black} emissiveIntensity={hovered ? 0.4 : 0.05} />,
    glow: <meshStandardMaterial color={p.glass} emissive={p.selection} emissiveIntensity={hovered ? .4 : .05} roughness={0.3} />,
  };
}

function SolarPanel({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  const panels = [-1.6, 0, 1.6];
  const cellMap = useMemo(() => {
    const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 512;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = p.metal; ctx.fillRect(0, 0, 256, 512);
      for (let x = 0; x < 4; x++) for (let y = 0; y < 8; y++) {
        ctx.fillStyle = p.panel; ctx.fillRect(x * 64 + 3, y * 64 + 3, 58, 58);
        ctx.fillStyle = p.metal; ctx.globalAlpha = .45;
        for (let k = 1; k < 5; k++) ctx.fillRect(x * 64 + 3, y * 64 + k * 12, 58, 1);
        ctx.globalAlpha = 1;
      }
    }
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; return texture;
  }, [p]);
  return (
    <group>
      {panels.map((x) => (
        <group key={x} position={[x, 0, 0]} rotation={[-0.5, 0, 0]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <boxGeometry args={[1.4, 0.08, 2]} />
            <meshStandardMaterial color={p.panel} roughness={0.25} metalness={0.7} emissive={p.selection} emissiveIntensity={hovered ? .15 : 0} />
          </mesh>
          <mesh position={[0, 1.14, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[1.32, 1.92]} />
            <meshPhysicalMaterial map={cellMap} metalness={.65} roughness={.23} clearcoat={.8} />
          </mesh>
          <mesh position={[0, 0.5, 0.35]} castShadow>
            <cylinderGeometry args={[0.07, 0.07, 1, 6]} />
            {m.dark}
          </mesh>
        </group>
      ))}
    </group>
  );
}

function OxygenGen({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  return (
    <group>
      <mesh position={[0, 0.9, 0]} castShadow>
        <cylinderGeometry args={[0.8, 0.9, 1.8, 32]} />
        {m.hull}
      </mesh>
      <mesh position={[0, 1.95, 0]} castShadow>
        <sphereGeometry args={[0.8, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
        {m.hull}
      </mesh>
      <mesh position={[1.1, 0.7, 0]} castShadow>
        <cylinderGeometry args={[0.35, 0.35, 1.4, 10]} />
        {m.accent}
      </mesh>
      <mesh position={[0.55, 1.2, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.08, 0.08, 1.2, 6]} />
        {m.dark}
      </mesh>
      {[.25,.75,1.25,1.75].map(y => <mesh key={y} position={[0,y,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.87,.025,6,32]} />{m.dark}</mesh>)}
      <mesh position={[0, 2.5, 0]}>
        <sphereGeometry args={[0.14, 8, 8]} />
        {m.glow}
      </mesh>
    </group>
  );
}

function IceExtractor({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  return (
    <group>
      <mesh position={[0, 0.35, 0]} castShadow>
        <boxGeometry args={[2.2, 0.7, 1.6]} />
        {m.dark}
      </mesh>
      {[.7,1.3,1.9].map(y => <group key={y}>
        <mesh position={[0,y,0]} rotation={[0,0,.55]} castShadow><boxGeometry args={[1.05,.07,.08]} />{m.hull}</mesh>
        <mesh position={[0,y,0]} rotation={[0,0,-.55]} castShadow><boxGeometry args={[1.05,.07,.08]} />{m.hull}</mesh>
      </group>)}
      {/* Drill tower */}
      <mesh position={[-0.5, 1.4, 0]} castShadow>
        <boxGeometry args={[0.25, 2.2, 0.25]} />
        {m.hull}
      </mesh>
      <mesh position={[0.5, 1.4, 0]} castShadow>
        <boxGeometry args={[0.25, 2.2, 0.25]} />
        {m.hull}
      </mesh>
      <mesh position={[0, 2.5, 0]} castShadow>
        <boxGeometry args={[1.3, 0.25, 0.3]} />
        {m.accent}
      </mesh>
      <mesh position={[0, 1.3, 0]}>
        <cylinderGeometry args={[0.09, 0.05, 2.4, 8]} />
        {m.glow}
      </mesh>
      {/* Pipes */}
      <mesh position={[1.3, 0.5, 0.4]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 1.6, 6]} />
        {m.hull}
      </mesh>
      <mesh position={[1.3, 0.9, 1.1]} castShadow>
        <cylinderGeometry args={[0.4, 0.45, 0.9, 10]} />
        {m.accent}
      </mesh>
    </group>
  );
}

function Greenhouse({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  return (
    <group>
      <mesh position={[0, 0.15, 0]} castShadow>
        <cylinderGeometry args={[1.7, 1.8, 0.3, 32]} />
        {m.dark}
      </mesh>
      {/* Crops */}
      {[-0.8, 0, 0.8].map((x) =>
        [-0.5, 0.5].map((z) => (
          <mesh key={`${x}-${z}`} position={[x, 0.55, z]}>
            <coneGeometry args={[0.22, 0.6, 6]} />
            <meshStandardMaterial color={p.crop} roughness={0.8} emissive={hovered ? p.crop : p.black} emissiveIntensity={hovered ? 0.4 : 0.05} />
          </mesh>
        )),
      )}
      {[-.8, 0, .8].map(x => <mesh key={x} position={[x, .36, 0]} castShadow><boxGeometry args={[.48, .15, 1.8]} />{m.hull}</mesh>)}
      {[0,1,2,3,4,5].map(i => <mesh key={i} position={[0,.3,0]} rotation={[0, i * Math.PI / 6, 0]} castShadow><torusGeometry args={[1.61, .025, 6, 48, Math.PI]} />{m.hull}</mesh>)}
      <mesh position={[0, .3, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[1.6,.04,8,48]} />{m.hull}</mesh>
      <mesh position={[0, .55, 1.6]} rotation={[Math.PI / 2,0,0]} castShadow><cylinderGeometry args={[.4,.4,.9,24]} />{m.hull}</mesh>
      {/* Transparent pressurised dome */}
      <mesh position={[0, 0.3, 0]}>
        <sphereGeometry args={[1.6, 40, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshPhysicalMaterial color={p.glass} transparent opacity={hovered ? .32 : .18} roughness={.07} metalness={.05} clearcoat={1} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
    </group>
  );
}

function Mine({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  return (
    <group>
      <mesh position={[0, 0.8, 0]} castShadow>
        <boxGeometry args={[1.8, 1.6, 1.4]} />
        {m.hull}
      </mesh>
      <mesh position={[0, 1.75, 0]} castShadow>
        <boxGeometry args={[1.2, 0.35, 1]} />
        {m.accent}
      </mesh>
      {/* Conveyor */}
      <group position={[1.6, 0.5, 0]} rotation={[0, 0, -0.5]}>
        <mesh castShadow>
          <boxGeometry args={[2.4, 0.18, 0.7]} />
          {m.dark}
        </mesh>
        {[-0.9, 0, 0.9].map((x) => (
          <mesh key={x} position={[x, -0.45, 0]}>
            <cylinderGeometry args={[0.06, 0.06, 0.9, 6]} />
            {m.dark}
          </mesh>
        ))}
      </group>
      <mesh position={[2.9, 0.3, 0]} castShadow>
        <boxGeometry args={[0.9, 0.6, 0.9]} />
        {m.accent}
      </mesh>
      <mesh position={[0, 2.1, 0]}>
        <sphereGeometry args={[0.12, 8, 8]} />
        {m.glow}
      </mesh>
    </group>
  );
}

function Shield({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  return (
    <group>
      {/* Arched canopy of shield panels */}
      {[-1, 0, 1].map((i) => (
        <mesh key={i} position={[i * 1.1, 1.5 + Math.abs(i) * -0.35, 0]} rotation={[0, 0, i * -0.35]} castShadow>
          <boxGeometry args={[1.1, 0.12, 2.4]} />
          <meshStandardMaterial color={p.metal} roughness={0.4} metalness={0.5} emissive={hovered ? p.selection : p.black} emissiveIntensity={hovered ? 0.5 : 0.08} />
        </mesh>
      ))}
      {[-1.5, 1.5].map((x) => (
        <mesh key={x} position={[x, 0.7, 0]} castShadow>
          <cylinderGeometry args={[0.08, 0.1, 1.4, 6]} />
          {m.dark}
        </mesh>
      ))}
      <mesh position={[0, 0.5, 0]} castShadow>
        <boxGeometry args={[1, 1, 1.6]} />
        {m.hull}
      </mesh>
    </group>
  );
}

function LandingPad({ hovered }: ModelProps) {
  const m = useMats(hovered);
  const p = useMemo(scenePalette, []);
  return (
    <group>
      <mesh position={[0, 0.12, 0]} receiveShadow castShadow>
        <cylinderGeometry args={[2.6, 2.8, 0.24, 24]} />
        {m.dark}
      </mesh>
      <mesh position={[0, 0.26, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[2, 2.3, 24]} />
        <meshStandardMaterial color={p.accent} emissive={p.accent} emissiveIntensity={hovered ? 0.9 : 0.35} side={THREE.DoubleSide} />
      </mesh>
      {/* Small lander */}
      <group position={[0, 0.24, 0]}>
        <mesh position={[0, 1, 0]} castShadow>
          <cylinderGeometry args={[0.55, 0.7, 1.4, 24]} />
          {m.hull}
        </mesh>
        <mesh position={[0, 1.9, 0]} castShadow>
          <coneGeometry args={[0.55, 0.7, 10]} />
          {m.accent}
        </mesh>
        {[0, 1, 2, 3].map((i) => {
          const a = (i / 4) * Math.PI * 2;
          return (
            <mesh key={i} position={[Math.cos(a) * 0.85, 0.45, Math.sin(a) * 0.85]} rotation={[0, 0, Math.cos(a) * 0.5]}>
              <cylinderGeometry args={[0.05, 0.05, 1, 6]} />
              {m.dark}
            </mesh>
          );
        })}
      </group>
    </group>
  );
}

const MODELS: Record<BuildingId | "pad", (p: ModelProps) => React.ReactNode> = {
  solar: SolarPanel,
  oxygen: OxygenGen,
  water: IceExtractor,
  greenhouse: Greenhouse,
  mine: Mine,
  shield: Shield,
  pad: LandingPad,
};

// Grows in with a spring when first built.
function Appear({ children }: { children: React.ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    const g = ref.current;
    if (!g) return;
    const next = THREE.MathUtils.damp(g.scale.x, 1, 6, Math.min(delta, 0.05));
    g.scale.setScalar(next);
  });
  return (
    <group ref={ref} scale={0.01}>
      {children}
    </group>
  );
}

export function Structure({
  id,
  count,
  hovered,
  onHover,
}: {
  id: BuildingId | "pad";
  count: number;
  hovered: boolean;
  onHover: (id: BuildingId | "pad" | null) => void;
}) {
  const p = useMemo(scenePalette, []);
  if (id !== "pad" && count <= 0) return null;
  const Model = MODELS[id];
  const [sx, sz] = SLOTS[id];
  const offsets = id === "pad" ? [[0, 0] as [number, number]] : unitOffsets(count);
  return (
    <group
      onPointerOver={(e) => {
        e.stopPropagation();
        onHover(id);
        document.body.style.cursor = "pointer";
      }}
      onPointerOut={() => {
        onHover(null);
        document.body.style.cursor = "auto";
      }}
      onClick={(e) => {
        e.stopPropagation();
        onHover(id);
      }}
    >
      {offsets.map(([ox, oz], i) => (
        <group key={i} position={[sx + ox, 0, sz + oz]}>
          <Appear>
            <Model hovered={hovered} />
          </Appear>
        </group>
      ))}
      {hovered && (
        <mesh position={[sx, 0.05, sz]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[2.2, 2.5, 32]} />
          <meshBasicMaterial color={p.selection} transparent opacity={0.7} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}
