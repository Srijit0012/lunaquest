import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import { clone } from 'three/examples/jsm/utils/SkeletonUtils.js';
import * as THREE from 'three';
import rigAsset from '@/assets/models/emu-decoded.glb.asset.json';
import { initialMotion, selectTarget, stepMotion, type InteractionTarget } from './astronaut-motion';

export function Astronaut({ interaction }: { interaction: { target: InteractionTarget; nonce: number } | null }) {
  const { scene } = useGLTF(rigAsset.url);
  const group = useRef<THREE.Group>(null);
  const motion = useRef(initialMotion());
  const data = useMemo(() => {
    const model = clone(scene);
    model.updateMatrixWorld(true);
    model.traverse(obj => { if (obj instanceof THREE.SkinnedMesh) { obj.skeleton.update(); obj.computeBoundingBox(); obj.computeBoundingSphere(); obj.frustumCulled = false; } });
    const box = new THREE.Box3().setFromObject(model);
    const scale = 1.85 / box.getSize(new THREE.Vector3()).y; const center = box.getCenter(new THREE.Vector3());
    model.scale.multiplyScalar(scale); model.position.set(-center.x * scale, -box.min.y * scale, -center.z * scale);
    const bones: { bone: THREE.Bone; rest: THREE.Quaternion }[] = [];
    model.traverse(obj => { if (obj instanceof THREE.Mesh) { obj.castShadow = true; obj.receiveShadow = true; } if (obj instanceof THREE.Bone) bones.push({ bone: obj, rest: obj.quaternion.clone() }); });
    return { model, bones };
  }, [scene]);
  useEffect(() => { if (interaction) motion.current = selectTarget(motion.current, interaction.target); }, [interaction]);
  useFrame((_, delta) => {
    const dt = Math.min(delta, .05), s = motion.current; stepMotion(s, dt);
    if (group.current) {
      group.current.position.set(s.x, .02, s.z);
      const next = s.route[0]; const yaw = next ? Math.atan2(next[0] - s.x, next[1] - s.z) : Math.PI;
      const desired = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
      group.current.quaternion.slerp(desired, 1 - Math.exp(-dt * 6));
      group.current.userData['phase'] = s.phase;
      document.querySelector('[data-planet-scene]')?.setAttribute('data-astronaut-phase', s.phase);
    }
    const walk = s.phase === 'walking', inspect = s.phase === 'inspect';
    for (const { bone, rest } of data.bones) {
      let angle = 0; const left = bone.name.endsWith('L'), sign = left ? 1 : -1;
      if (bone.name.startsWith('UpperLeg')) angle = walk ? Math.sin(s.time * 6) * .35 * sign : 0;
      if (bone.name.startsWith('LowerLeg')) angle = walk ? Math.max(0, Math.sin(s.time * 6) * sign) * .5 : 0;
      if (bone.name.startsWith('UpperArm')) angle = walk ? Math.sin(s.time * 6) * -.23 * sign : inspect && !left ? -.65 : 0;
      if (bone.name.startsWith('LowerArm')) angle = inspect && !left ? -.55 + Math.sin(s.time * 3) * .15 : -.12;
      if (bone.name === 'Head') angle = inspect ? .14 + Math.sin(s.time * 2) * .06 : Math.sin(s.time * .8) * .025;
      if (bone.name === 'Chest') angle = Math.sin(s.time * 1.3) * .015;
      const desired = rest.clone().multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0), angle));
      if (bone.name.startsWith('UpperArm')) desired.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1), sign * 1.05));
      bone.quaternion.slerp(desired, 1 - Math.exp(-dt * 10));
    }
  });
  return <group ref={group} position={[4.5, .02, 3.5]}><primitive object={data.model} /></group>;
}
