import { useMemo } from 'react';
import * as THREE from 'three';
import { scenePalette } from './palette';

export function ServiceModule({ laboratory = false }: { laboratory?: boolean }) {
  const p = useMemo(scenePalette, []);
  return <group>
    <mesh position={[0, 1.2, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow><cylinderGeometry args={[.95, .95, 3.4, 32]} /><meshStandardMaterial color={p.hull} metalness={.35} roughness={.6} /></mesh>
    {[-1.35, -.65, .65, 1.35].map(z => <mesh key={z} position={[0, 1.2, z]} castShadow><torusGeometry args={[.965, .035, 8, 32]} /><meshStandardMaterial color={p.metal} metalness={.75} roughness={.3} /></mesh>)}
    {[-.65, .65].map(x => [-1.15, 1.15].map(z => <mesh key={`${x}-${z}`} position={[x, .3, z]} castShadow><boxGeometry args={[.16, .6, .16]} /><meshStandardMaterial color={p.metal} metalness={.7} roughness={.5} /></mesh>))}
    <mesh position={[0, 1.2, 1.74]}><circleGeometry args={[.72, 32]} /><meshStandardMaterial color={p.dark} metalness={.5} roughness={.5} /></mesh>
    <mesh position={[0, 1.2, 1.77]}><torusGeometry args={[.55, .055, 8, 32]} /><meshStandardMaterial color={p.metal} metalness={.85} roughness={.3} /></mesh>
    <mesh position={[0, .35, 2.05]} castShadow><boxGeometry args={[.9, .12, .65]} /><meshStandardMaterial color={p.dark} roughness={.9} /></mesh>
    {[-.5, .5].map(x => <mesh key={x} position={[x, 1.3, .4]} rotation={[0, x < 0 ? -Math.PI / 2 : Math.PI / 2, 0]}><circleGeometry args={[.24, 24]} /><meshPhysicalMaterial color={p.glass} metalness={.1} roughness={.08} clearcoat={1} /></mesh>)}
    <mesh position={[.45, 2.5, -.5]} castShadow><cylinderGeometry args={[.015, .025, 1.3, 8]} /><meshStandardMaterial color={p.metal} metalness={.85} roughness={.3} /></mesh>
    {laboratory && <group position={[1.25, .7, -.5]}>
      <mesh castShadow><boxGeometry args={[.65, 1.1, .8]} /><meshStandardMaterial color={p.hull} metalness={.4} roughness={.55} /></mesh>
      {[0, 1, 2, 3].map(i => <mesh key={i} position={[.34, -.3 + i * .2, 0]}><boxGeometry args={[.025, .045, .65]} /><meshStandardMaterial color={p.dark} roughness={.8} /></mesh>)}
    </group>}
  </group>;
}

export function Dish() {
  const p = useMemo(scenePalette, []);
  const geometry = useMemo(() => {
    const points = Array.from({ length: 18 }, (_, i) => { const r = i / 17; return new THREE.Vector2(r, r * r * .45); });
    return new THREE.LatheGeometry(points, 40);
  }, []);
  return <group>
    <mesh position={[0, .9, 0]} castShadow><cylinderGeometry args={[.07, .16, 1.8, 12]} /><meshStandardMaterial color={p.metal} metalness={.7} roughness={.4} /></mesh>
    <group position={[0, 1.9, 0]} rotation={[.6, 0, -.3]}>
      <mesh geometry={geometry} castShadow><meshStandardMaterial color={p.hull} metalness={.65} roughness={.3} side={THREE.DoubleSide} /></mesh>
      <mesh position={[0, .4, 0]}><cylinderGeometry args={[.015, .015, .8, 8]} /><meshStandardMaterial color={p.dark} metalness={.7} roughness={.4} /></mesh>
      <mesh position={[0, .82, 0]}><sphereGeometry args={[.09, 12, 8]} /><meshStandardMaterial color={p.accent} metalness={.7} roughness={.4} /></mesh>
    </group>
    <mesh position={[0, .07, 0]} castShadow><cylinderGeometry args={[.6, .7, .14, 16]} /><meshStandardMaterial color={p.dark} roughness={.9} /></mesh>
  </group>;
}

export function ColonySupport() {
  return <group>
    <group position={[-3.7, 0, 4]} rotation={[0, .25, 0]}><ServiceModule /></group>
    <group position={[3.2, 0, -3.5]} rotation={[0, -.3, 0]}><ServiceModule laboratory /></group>
    <group position={[-5.7, 0, -.5]}><Dish /></group>
  </group>;
}
