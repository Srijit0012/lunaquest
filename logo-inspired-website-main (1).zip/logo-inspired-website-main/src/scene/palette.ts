// Resolve the same semantic material roles used by the site theme.
export function scenePalette() {
  const css = getComputedStyle(document.documentElement);
  const value = (role: string) => css.getPropertyValue(`--scene-${role}`).trim();
  return {
    hull: value('hull'), metal: value('metal'), dark: value('dark'), accent: value('accent'),
    glass: value('glass'), panel: value('panel'), crop: value('crop'), selection: value('selection'),
    black: value('black'), moon: value('moon'), mars: value('mars'), sky: value('mars-sky'),
    sun: value('sun'), atmosphere: value('atmosphere'), warm: value('warm'),
  };
}

export type GraphicsQuality = 'low' | 'balanced' | 'high';
export const GRAPHICS = {
  low: { dpr: 1, shadows: 1024, rocks: 100, ao: false },
  balanced: { dpr: 1.5, shadows: 2048, rocks: 240, ao: false },
  high: { dpr: 2, shadows: 2048, rocks: 420, ao: true },
} as const;