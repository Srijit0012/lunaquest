import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useTexture } from '@react-three/drei';
import * as THREE from 'three';
import earthMap from '@/assets/textures/earth.jpg.asset.json';
import moonMap from '@/assets/textures/moon-world.jpg.asset.json';
import moonHeight from '@/assets/textures/moon-height.jpg.asset.json';
import marsMap from '@/assets/textures/mars-globe.jpg.asset.json';
import { scenePalette } from './palette';

export const SUN_POSITION: [number, number, number] = [-330, 150, -300];
export const SUN_LIGHT: [number, number, number] = [-55, 25, -50];

function glowMaterial(color: string, strength: number) {
  return new THREE.ShaderMaterial({
    uniforms: { tint: { value: new THREE.Color(color) }, strength: { value: strength } },
    vertexShader: 'varying vec3 n; varying vec3 v; void main(){vec4 p=modelViewMatrix*vec4(position,1.); n=normalize(normalMatrix*normal);v=normalize(-p.xyz);gl_Position=projectionMatrix*p;}',
    fragmentShader: 'uniform vec3 tint;uniform float strength;varying vec3 n;varying vec3 v;void main(){float rim=pow(1.-abs(dot(normalize(n),normalize(v))),3.);gl_FragColor=vec4(tint,rim*strength);}',
    transparent: true, depthWrite: false, side: THREE.FrontSide,
  });
}
export function Sun({ position = SUN_POSITION, radius = 11 }: { position?: [number, number, number]; radius?: number }) {
  const p = useMemo(scenePalette, []);
  const material = useMemo(() => glowMaterial(p.sun, .35), [p]);
  const surface = useMemo(() => new THREE.ShaderMaterial({
    uniforms: { tint: { value: new THREE.Color(p.sun) } },
    vertexShader: 'varying vec3 p; void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: 'uniform vec3 tint;varying vec3 p;void main(){float grain=sin(p.x*73.)*sin(p.y*81.+sin(p.z*35.));float patches=sin(p.x*8.+p.z*9.)*sin(p.y*11.);gl_FragColor=vec4(tint*(1.15+grain*.06+patches*.12),1.);}',
  }), [p]);
  return <group position={position} scale={radius / 1.7}>
    <mesh material={surface}><sphereGeometry args={[1.7, 48, 32]} /></mesh>
    <mesh material={material}><sphereGeometry args={[1.9, 48, 32]} /></mesh>
  </group>;
}

export type BodyId = 'earth' | 'moon' | 'mars' | 'sun';
export function CelestialBody({ body, radius = 1 }: { body: BodyId; radius?: number }) {
  const p = useMemo(scenePalette, []);
  const source = useTexture(body === 'moon' ? moonMap.url : body === 'mars' ? marsMap.url : earthMap.url);
  const bump = useTexture(moonHeight.url);
  const surface = useRef<THREE.Mesh>(null);
  const map = useMemo(() => { const t = source.clone(); t.colorSpace = THREE.SRGBColorSpace; t.needsUpdate = true; return t; }, [source]);
  const clouds = useRef<THREE.Mesh>(null);
  const atmosphere = useMemo(() => glowMaterial(p.atmosphere, .7), [p]);
  const cloudMap = useMemo(() => {
    const w = 512, h = 256, bytes = new Uint8Array(w * h * 4);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const wave = Math.sin(x * .037 + Math.sin(y * .072) * 5) + Math.sin(y * .081 + Math.cos(x * .021) * 4) + Math.sin(x * .11 + y * .063) * .45;
      const i = (y * w + x) * 4;
      bytes[i] = bytes[i + 1] = bytes[i + 2] = 255; bytes[i + 3] = Math.max(0, Math.min(200, (wave - .65) * 130));
    }
    const t = new THREE.DataTexture(bytes, w, h); t.needsUpdate = true; return t;
  }, []);
  const marsAtmosphere = useMemo(() => glowMaterial(p.warm, .18), [p]);
  useFrame((_, dt) => { const step = Math.min(dt, .05); if (clouds.current) clouds.current.rotation.y += step * .018; if (surface.current) surface.current.rotation.y += step * .012; });
  if (body === 'sun') return <Sun position={[0, 0, 0]} radius={radius} />;
  return <group scale={radius} rotation={[0, -1.7, .18]}>
    <mesh ref={surface}><sphereGeometry args={[1, 96, 64]} /><meshStandardMaterial map={map} bumpMap={body === 'moon' ? bump : body === 'mars' ? map : null} bumpScale={body === 'moon' ? .015 : .008} roughness={body === 'earth' ? .68 : .96} metalness={0} /></mesh>
    {body === 'earth' && <>
      <mesh ref={clouds}><sphereGeometry args={[1.009, 64, 48]} /><meshStandardMaterial map={cloudMap} transparent depthWrite={false} roughness={1} /></mesh>
      <mesh material={atmosphere}><sphereGeometry args={[1.035, 64, 48]} /></mesh>
    </>}
    {body === 'mars' && <>
      <mesh material={marsAtmosphere}><sphereGeometry args={[1.02, 64, 48]} /></mesh>
      {[0, Math.PI].map(angle => <mesh key={angle} rotation={[angle, 0, 0]}><sphereGeometry args={[1.002, 64, 12, 0, Math.PI * 2, 0, .14]} /><meshStandardMaterial color={p.hull} roughness={1} /></mesh>)}
    </>}
  </group>;
}
export function Earth({ distant = false }: { distant?: boolean }) {
  return <group position={[-170, 120, -360]}><CelestialBody body="earth" radius={distant ? .45 : 7} /></group>;
}
