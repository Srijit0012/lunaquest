import { useEffect, useMemo, useRef } from 'react';
import { useTexture } from '@react-three/drei';
import * as THREE from 'three';
import type { MissionId } from '@/lib/sim';
import { scenePalette, GRAPHICS, type GraphicsQuality } from './palette';
import moonColor from '@/assets/textures/moon_01-Diffuse.jpg.asset.json';
import moonNormal from '@/assets/textures/moon_01-nor_gl.jpg.asset.json';
import moonRough from '@/assets/textures/moon_01-Rough.jpg.asset.json';
import marsColor from '@/assets/textures/rocky_terrain_02-Diffuse.jpg.asset.json';
import marsNormal from '@/assets/textures/rocky_terrain_02-nor_gl.jpg.asset.json';
import marsRough from '@/assets/textures/rocky_terrain_02-Rough.jpg.asset.json';

export function seeded(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = seeded(71);
const craters = Array.from({ length: 30 }, () => ({ x: (rand() - .5) * 150, z: (rand() - .5) * 150, r: 3 + rand() * 9, depth: .7 + rand() * 2.1 }));
export const PLANET_RADIUS = 260;
export function terrainHeight(x: number, z: number, mission: MissionId) {
  const r = Math.hypot(x, z);
  // Planetary curvature beyond the apron drops the land below a true curved horizon.
  const curve = (r * r) / (2 * PLANET_RADIUS) * THREE.MathUtils.smoothstep(r, 22, 45);
  // A compact graded colony apron keeps all existing construction slots grounded.
  const blend = THREE.MathUtils.smoothstep(Math.hypot(x, z), 19, 30);
  let h = Math.sin(x * .24) * Math.cos(z * .19) * .45 + Math.sin(z * .51 + x * .2) * .12;
  if (mission === 'moon') {
    for (const c of craters) {
      const d = Math.hypot(x - c.x, z - c.z) / c.r;
      if (d < 1.4) h += -c.depth * Math.exp(-d * d * 3) + c.depth * .5 * Math.exp(-(((d - 1) * 7) ** 2));
    }
  } else {
    h += Math.sin(x * .06 + z * .04) * 2 + Math.cos(z * .09) * 1.2;
    const mountain = Math.max(0, Math.abs(z) - 30) / 16;
    h += mountain * (2.5 + Math.sin(x * .12) * Math.sin(x * .31) * 3);
  }
  return h * blend - curve;
}

function Rocks({ mission, quality }: { mission: MissionId; quality: GraphicsQuality }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const p = useMemo(scenePalette, []);
  const count = GRAPHICS[quality].rocks;
  const geometry = useMemo(() => {
    const geo = new THREE.IcosahedronGeometry(1, 2);
    const pos = geo.attributes['position'];
    if (!pos) return geo;
    for (let i = 0; i < pos.count; i++) {
      const factor = 1 + Math.sin(pos.getX(i) * 13 + pos.getZ(i) * 8) * .17;
      pos.setXYZ(i, pos.getX(i) * factor, pos.getY(i) * factor, pos.getZ(i) * factor);
    }
    geo.computeVertexNormals(); return geo;
  }, []);
  useEffect(() => {
    const mesh = ref.current; if (!mesh) return;
    const rng = seeded(345), dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const angle = rng() * Math.PI * 2, r = 20 + rng() * 52;
      const x = Math.cos(angle) * r, z = Math.sin(angle) * r;
      const s = .08 + rng() ** 4 * 2.1;
      dummy.position.set(x, terrainHeight(x, z, mission) + s * .22, z);
      dummy.rotation.set(rng(), rng() * 6, rng()); dummy.scale.set(s, s * .7, s * 1.25); dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      mesh.setColorAt(i, new THREE.Color(mission === 'moon' ? p.moon : p.mars).multiplyScalar(.6 + rng() * .6));
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [count, mission, p]);
  return <instancedMesh ref={ref} args={[geometry, undefined, count]} castShadow receiveShadow><meshStandardMaterial roughness={.95} /></instancedMesh>;
}

export function Terrain({ mission, quality }: { mission: MissionId; quality: GraphicsQuality }) {
  const p = useMemo(scenePalette, []);
  const source = mission === 'moon' ? [moonColor.url, moonNormal.url, moonRough.url] : [marsColor.url, marsNormal.url, marsRough.url];
  const loaded = useTexture(source);
  const maps = useMemo(() => loaded.map((original, i) => {
    const t = original.clone(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(37, 37);
    t.colorSpace = i === 0 ? THREE.SRGBColorSpace : THREE.NoColorSpace; t.anisotropy = 4; t.needsUpdate = true; return t;
  }), [loaded]);
  useEffect(() => () => maps.forEach(t => t.dispose()), [maps]);
  const geometry = useMemo(() => {
    const geo = new THREE.RingGeometry(.01, 150, 256, 150); geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes['position'];
    if (!pos) return geo;
    for (let i = 0; i < pos.count; i++) pos.setY(i, terrainHeight(pos.getX(i), pos.getZ(i), mission));
    geo.computeVertexNormals(); return geo;
  }, [mission]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return <group>
    <mesh geometry={geometry} receiveShadow>
      <meshStandardMaterial map={maps[0] ?? null} normalMap={maps[1] ?? null} roughnessMap={maps[2] ?? null} normalScale={new THREE.Vector2(.8, .8)} color={mission === 'moon' ? p.hull : p.mars} roughness={1} />
    </mesh>
    <Rocks mission={mission} quality={quality} />
  </group>;
}
