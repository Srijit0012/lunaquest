import { Suspense, useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { CelestialBody, type BodyId } from './celestial';
import { scenePalette } from './palette';

function GalleryWorld({ bodies }: { bodies: BodyId[] }) {
  const p = scenePalette();
  return <>
    <ambientLight intensity={.45} />
    <directionalLight position={[-5, 4, 6]} intensity={2.4} color={p.sun} />
    {bodies.map((body, i) => <group key={body} position={[(i - (bodies.length - 1) / 2) * 2.8, 0, 0]}>
      <Suspense fallback={null}><CelestialBody body={body} radius={1} /></Suspense>
    </group>)}
    <OrbitControls enablePan={false} enableZoom minDistance={3} maxDistance={20} enableDamping />
  </>;
}
export function PlanetGallery({ bodies }: { bodies: BodyId[] }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return <div className="w-full">
    <div data-globe-view className="h-48 w-full sm:h-56">
      {mounted && <Canvas camera={{ position: [0, 1, bodies.length > 2 ? 8 : 5], fov: 35 }} dpr={[1, 1.5]} gl={{ alpha: true, antialias: true }}><GalleryWorld bodies={bodies} /></Canvas>}
    </div>
    <div className="flex justify-around pb-3 text-xs font-semibold uppercase text-muted-foreground">{bodies.map(body => <span key={body}>{body}</span>)}</div>
  </div>;
}
