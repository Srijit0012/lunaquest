export type InteractionTarget = 'solar' | 'oxygen' | 'water' | 'greenhouse' | 'mine' | 'shield' | 'habitat' | 'laboratory' | 'antenna';
export const INTERACTION_POINTS: Record<InteractionTarget, [number, number]> = {
  solar: [-11, -2.8], oxygen: [9, 0], water: [-9, 8], greenhouse: [2, -6], mine: [12, 9], shield: [-2, 2.2],
  habitat: [-3.2, 6.5], laboratory: [2.5, -.8], antenna: [-5.7, 2],
};
export type MotionState = { x: number; z: number; phase: 'idle' | 'walking' | 'inspect'; time: number; target: InteractionTarget | null; route: [number, number][] };
export function initialMotion(): MotionState { return { x: 4.5, z: 3.5, phase: 'idle', time: 0, target: null, route: [] }; }
// Route along a clear southern perimeter and approach from the front, never through a facility.
export function selectTarget(s: MotionState, target: InteractionTarget): MotionState {
  const [x, z] = INTERACTION_POINTS[target];
  return { ...s, phase: 'walking', time: 0, target, route: [[s.x, 13], [x, 13], [x, z]] };
}
export function stepMotion(s: MotionState, dt: number): void {
  s.time += dt;
  if (s.phase === 'inspect') { if (s.time >= 3.5) { s.phase = 'idle'; s.time = 0; } return; }
  const point = s.route[0]; if (!point) return;
  const dx = point[0] - s.x, dz = point[1] - s.z, d = Math.hypot(dx, dz), step = dt * 1.5;
  if (d <= step) { s.x = point[0]; s.z = point[1]; s.route.shift(); if (!s.route.length) { s.phase = 'inspect'; s.time = 0; } }
  else { s.x += dx / d * step; s.z += dz / d * step; }
}
