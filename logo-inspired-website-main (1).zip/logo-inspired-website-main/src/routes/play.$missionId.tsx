import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { BUILDINGS, MISSIONS, build, newGame, nextSol, type BuildingId, type MissionId } from "@/lib/sim";
import { PlanetScene } from "@/scene/PlanetScene";
import type { StructureInfo } from "@/scene/structures";
import type { GraphicsQuality } from "@/scene/palette";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Focus, Orbit } from "lucide-react";
import { PlanetGallery } from "@/scene/PlanetGallery";
import type { InteractionTarget } from "@/scene/astronaut-motion";

export const Route = createFileRoute("/play/$missionId")({
  loader: ({ params }) => {
    if (!(params.missionId in MISSIONS)) throw notFound();
    return { id: params.missionId as MissionId };
  },
  head: () => ({
    meta: [
      { title: "Mission Control — AstroQuest" },
      { name: "description", content: "Run your space settlement one sol at a time." },
      { property: "og:title", content: "Mission Control — AstroQuest" },
      { property: "og:description", content: "Run your space settlement one sol at a time." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Play,
});

function Play() {
  const { id } = Route.useLoaderData();
  const [s, setS] = useState(() => newGame(id));
  const [info, setInfo] = useState<StructureInfo | null>(null);
  const [mounted, setMounted] = useState(false);
  const [quality, setQuality] = useState<GraphicsQuality>("balanced");
  const [cameraMode, setCameraMode] = useState<"colony" | "astronaut">("colony");
  const [interaction, setInteraction] = useState<{ target: InteractionTarget; nonce: number } | null>(null);
  const inspect = (target: InteractionTarget) => setInteraction(x => ({ target, nonce: (x?.nonce ?? 0) + 1 }));
  useEffect(() => setMounted(true), []);
  const m = MISSIONS[id];

  return (
    <main data-mission={id} className="min-h-screen bg-background px-6 py-10 font-sans">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <Link to="/missions" className="text-sm text-muted-foreground hover:text-primary">← Missions</Link>
          <h1 className="font-display text-2xl font-extrabold text-gradient-brand">{m.name}</h1>
          <p className="font-display text-primary">SOL {Math.min(s.sol, m.days)} / {m.days}</p>
        </div>

        {/* Immersive planetary environment */}
        <section
          data-planet-scene
          className="relative mt-6 h-[460px] overflow-hidden border-y border-border sm:h-[560px]"
        >
          {mounted ? (
            <PlanetScene mission={id} buildings={s.buildings} onHoverInfo={setInfo} quality={quality} cameraMode={cameraMode} interaction={interaction} />
          ) : (
            <div className="flex h-full items-center justify-center bg-card text-muted-foreground">
              Loading planetary environment…
            </div>
          )}
          {/* Hover / tap info card */}
          {info && (
            <aside className="pointer-events-none absolute bottom-4 left-4 right-4 max-w-md rounded-xl border border-border bg-card/85 p-4 backdrop-blur-md sm:right-auto">
              <h3 className="font-display text-sm font-bold tracking-widest text-primary">{info.name.toUpperCase()}</h3>
              <p className="mt-1 text-sm text-card-foreground">{info.purpose}</p>
              <p className="mt-2 text-xs text-accent">🔬 {info.fact}</p>
            </aside>
          )}
          <div className="absolute left-3 right-3 top-3 flex items-center justify-between gap-2">
            <div className="flex gap-1">
              <Button variant="outline" size="icon" aria-label="View colony" title="View colony" onClick={() => setCameraMode("colony")}><Orbit /></Button>
              <Button variant="outline" size="icon" aria-label="View astronaut" title="View astronaut" onClick={() => setCameraMode("astronaut")}><Focus /></Button>
            </div>
            <Select value={quality} onValueChange={value => {
              if (value === "low" || value === "balanced" || value === "high") setQuality(value);
            }}>
              <SelectTrigger aria-label="Graphics quality" className="w-36 bg-card/85 backdrop-blur-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low graphics</SelectItem>
                <SelectItem value="balanced">Balanced</SelectItem>
                <SelectItem value="high">High graphics</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </section>

        <section className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-6">
          {[...Object.entries(s.res), ["health", s.health] as const].map(([k, v]) => (
            <div key={k} className="rounded-xl border border-border bg-card p-3 text-center">
              <div className="text-xs capitalize text-muted-foreground">{k === "health" ? "Crew health" : k}</div>
              <div className={`font-display text-2xl ${Number(v) < 15 ? "text-destructive" : "text-primary"}`}>{v}</div>
            </div>
          ))}
        </section>

        {s.status !== "playing" && (
          <div className="mt-6 rounded-xl border border-accent bg-card p-6 text-center">
            <h2 className="font-display text-2xl text-accent">{s.status === "won" ? "MISSION COMPLETE!" : "MISSION FAILED"}</h2>
            <Button onClick={() => { setS(newGame(id)); setInteraction(null); }} className="mt-4">TRY AGAIN</Button>
          </div>
        )}

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <section className="lg:col-span-2">
            <h2 className="font-display text-sm tracking-widest text-accent">BUILD FACILITIES</h2>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {(Object.keys(BUILDINGS) as BuildingId[]).map((b) => {
                const infoB = BUILDINGS[b];
                const can = s.status === "playing" && s.res.materials >= infoB.cost;
                return (
                  <Button variant="outline" key={b} disabled={!can} onClick={() => { setS((x) => build(x, b)); inspect(b); }}
                    className="h-auto flex-col items-stretch whitespace-normal rounded-lg bg-card p-4 text-left">
                    <div className="flex justify-between"><span className="font-semibold text-card-foreground">{infoB.name}</span><span className="text-sm text-primary">×{s.buildings[b]}</span></div>
                    <p className="mt-1 text-xs text-muted-foreground">{infoB.desc}</p>
                    <p className="mt-2 text-xs text-accent">Cost: {infoB.cost} materials</p>
                  </Button>
                );
              })}
            </div>
            <Button disabled={s.status !== "playing"} onClick={() => setS((x) => nextSol(x))}
              className="mt-6 w-full rounded-lg bg-gradient-brand py-3 font-display font-semibold text-primary-foreground shadow-glow disabled:opacity-40">
              END SOL →
            </Button>
            <h2 className="mt-6 font-display text-sm text-accent">CREW INSPECTIONS</h2>
            <div className="mt-3 flex flex-wrap gap-2">{([['habitat', 'Crew habitat'], ['laboratory', 'Research laboratory'], ['antenna', 'Communication antenna']] as const).map(([target, label]) => <Button key={target} variant="outline" onClick={() => inspect(target)}>{label}</Button>)}</div>
          </section>
          <section>
            <h2 className="font-display text-sm tracking-widest text-accent">MISSION LOG</h2>
            <ul className="mt-3 max-h-[480px] space-y-2 overflow-y-auto rounded-xl border border-border bg-card p-4 text-sm text-card-foreground">
              {s.log.map((l, i) => <li key={i}>{l}</li>)}
            </ul>
          </section>
        </div>
        <div className="mt-8 max-w-sm"><PlanetGallery bodies={[id]} /></div>
      </div>
    </main>
  );
}
