import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { MISSIONS, type MissionId } from "@/lib/sim";
import { PlanetGallery } from "@/scene/PlanetGallery";

export const Route = createFileRoute("/briefing/$missionId")({
  loader: ({ params }) => {
    if (!(params.missionId in MISSIONS)) throw notFound();
    return MISSIONS[params.missionId as MissionId];
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.name ?? "Mission"} Briefing — AstroQuest` },
      { name: "description", content: "Your mission briefing before landing." },
      { property: "og:title", content: `${loaderData?.name ?? "Mission"} Briefing — AstroQuest` },
      { property: "og:description", content: "Your mission briefing before landing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Briefing,
});

function Briefing() {
  const m = Route.useLoaderData();
  return (
    <main data-mission={m.id} className="min-h-screen bg-background px-6 py-16 font-sans">
      <Link to="/missions" className="text-sm text-muted-foreground hover:text-primary">← Back</Link>
      <div className="mx-auto mt-6 max-w-2xl rounded-2xl border border-border bg-card p-8 shadow-glow">
        <p className="font-display text-xs tracking-widest text-accent">MISSION BRIEFING</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold text-gradient-brand">{m.name}</h1>
        <PlanetGallery bodies={[m.id]} />
        <ol className="mt-6 space-y-3 text-card-foreground">
          {m.briefing.map((b, i) => (
            <li key={b}><span className="font-display text-primary">{i + 1}.</span> {b}</li>
          ))}
        </ol>
        <div className="mt-6 grid grid-cols-5 gap-2 text-center text-xs">
          {Object.entries(m.start).map(([k, v]) => (
            <div key={k} className="rounded-lg bg-muted p-2"><div className="capitalize text-muted-foreground">{k}</div><div className="font-display text-lg text-primary">{v}</div></div>
          ))}
        </div>
        <Link to="/play/$missionId" params={{ missionId: m.id }} className="mt-8 inline-block rounded-lg bg-gradient-brand px-6 py-3 font-display text-sm font-semibold text-primary-foreground">
          LAUNCH MISSION
        </Link>
      </div>
    </main>
  );
}
