import { MISSIONS } from "@/lib/sim";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PlanetGallery } from "@/scene/PlanetGallery";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/missions")({
  head: () => ({
    meta: [
      { title: "Choose Your Mission — AstroQuest" },
      { name: "description", content: "Pick a Moon outpost or a Mars colony mission." },
      { property: "og:title", content: "Choose Your Mission — AstroQuest" },
      { property: "og:description", content: "Pick a Moon outpost or a Mars colony mission." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Missions,
});

const missions = Object.values(MISSIONS);

function Missions() {
  return (
    <main className="min-h-screen bg-page px-6 py-16 font-sans">
      <Link to="/" className="text-sm text-muted-foreground hover:text-primary">← Back</Link>
      <h1 className="mt-6 text-center font-display text-4xl font-extrabold text-gradient-brand">SELECT YOUR MISSION</h1>
      <div className="mx-auto mt-12 grid max-w-5xl gap-8 md:grid-cols-2">
        {missions.map((m) => (
          <article key={m.name} data-tone={m.id} className={`rounded-2xl border border-border p-6 shadow-card transition duration-300 hover:-translate-y-1 hover:border-accent ${m.id === "moon" ? "bg-tone-moon" : "bg-tone-mars"}`}>
            <PlanetGallery bodies={[m.id]} />
            <h2 className="font-display text-2xl font-bold text-primary">{m.name}</h2>
            <p className="mt-2 text-muted-foreground">{m.desc}</p>
            <p className="mt-4 text-sm"><span className="text-accent">Difficulty:</span> {m.difficulty} · <span className="text-accent">Duration:</span> {m.days} sols</p>
            <ul className="mt-4 space-y-1 text-sm text-card-foreground">
              {m.traits.map((t) => <li key={t}>• {t}</li>)}
            </ul>
            <Button asChild className="mt-6"><Link to="/briefing/$missionId" params={{ missionId: m.id }}>
              SELECT MISSION
            </Link></Button>
          </article>
        ))}
      </div>
    </main>
  );
}
