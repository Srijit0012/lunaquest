import { createFileRoute, Link } from "@tanstack/react-router";
import { PlanetGallery } from "@/scene/PlanetGallery";

export const Route = createFileRoute("/explore")({
  head: () => ({
    meta: [
      { title: "Explore the Universe — AstroQuest" },
      { name: "description", content: "Learn key facts about the Moon and Mars before your mission." },
      { property: "og:title", content: "Explore the Universe — AstroQuest" },
      { property: "og:description", content: "Learn key facts about the Moon and Mars before your mission." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Explore,
});

const facts = [
  { title: "The Moon", items: ["384,400 km from Earth", "Day temps up to 127 °C, nights down to −173 °C", "Water ice hides in shadowed polar craters"] },
  { title: "Mars", items: ["Average 225 million km from Earth", "Atmosphere is 95% carbon dioxide", "Dust storms can cover the whole planet"] },
  { title: "Staying Alive", items: ["Each astronaut needs about 0.84 kg of oxygen a day", "Solar panels and batteries power the base", "Shielding protects crews from radiation"] },
];

function Explore() {
  return (
    <main className="min-h-screen bg-background px-6 py-16 font-sans">
      <Link to="/" className="text-sm text-muted-foreground hover:text-primary">← Back</Link>
      <h1 className="mt-6 text-center font-display text-4xl font-extrabold text-gradient-brand">EXPLORE THE UNIVERSE</h1>
      <div className="mx-auto mt-6 max-w-5xl"><PlanetGallery bodies={["earth", "moon", "mars", "sun"]} /></div>
      <div className="mx-auto mt-12 grid max-w-5xl gap-6 md:grid-cols-3">
        {facts.map((f) => (
          <article key={f.title} className="rounded-2xl border border-border bg-card p-6">
            <h2 className="font-display text-xl font-bold text-accent">{f.title}</h2>
            <ul className="mt-3 space-y-2 text-sm text-card-foreground">
              {f.items.map((i) => <li key={i}>• {i}</li>)}
            </ul>
          </article>
        ))}
      </div>
      <div className="mt-12 text-center">
        <Link to="/missions" className="rounded-lg bg-gradient-brand px-6 py-3 font-display text-sm font-semibold text-primary-foreground shadow-glow">START YOUR MISSION</Link>
      </div>
    </main>
  );
}
