import { createFileRoute, Link } from "@tanstack/react-router";
import logo from "@/assets/astroquest-new-logo.jpeg.asset.json";
import { Button } from "@/components/ui/button";
import { PlanetGallery } from "@/scene/PlanetGallery";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AstroQuest — Junior Astronaut Mission Simulator" },
      { name: "description", content: "Build and run your own Moon or Mars colony in this STEM space simulator." },
      { property: "og:title", content: "AstroQuest — Junior Astronaut Mission Simulator" },
      { property: "og:description", content: "Build and run your own Moon or Mars colony in this STEM space simulator." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="flex min-h-screen flex-col items-center bg-page px-6 pb-10 pt-6 text-center font-sans">
      <h1 className="sr-only">AstroQuest</h1>
      <img src={logo.url} alt="AstroQuest — Explore, Build, Thrive" className="w-full max-w-lg" />
      <div className="mt-3 flex flex-wrap justify-center gap-3">
        <Button asChild size="lg"><Link to="/missions">
          START YOUR MISSION
        </Link></Button>
        <Button asChild size="lg" variant="outline"><Link to="/explore">
          EXPLORE THE UNIVERSE
        </Link></Button>
      </div>
      <div className="mt-8 w-full max-w-4xl"><PlanetGallery bodies={["earth", "moon", "mars", "sun"]} /></div>
    </main>
  );
}
