# Scene resources

- New AstroQuest logo: user-supplied image, used without modification; favicon cropped from the same artwork.
- Whole-Moon albedo and elevation: NASA Scientific Visualization Studio CGI Moon Kit, https://svs.gsfc.nasa.gov/4720/ ; LRO/LROC/LOLA imagery, NASA public media guidelines. Albedo converted from 2k TIFF to JPEG. https://svs.gsfc.nasa.gov/vis/a000000/a004700/a004720/lroc_color_poles_2k.tif and ldem_3_8bit.jpg.
- Whole-Mars texture: NASA/JPL/Caltech/USGS Viking global map, https://space.jpl.nasa.gov/tmaps/mars.html , downloaded from https://space.jpl.nasa.gov/tmaps/pix/mar0kuu2.jpg (1440 × 720). Polar cap shells and thin atmospheric rim are visual approximations.
- Animated astronaut: existing Quaternius CC0 Space Kit astronaut, https://quaternius.com/packs/spacekit.html . Uses its existing skeleton with authored joint poses and blended transitions, not captured/professional animation clips. The static NASA model is retained as an asset but is not the animated character.

- Astronaut: NASA 3D Resources, credited to DigitalSpace Corporation: https://science.nasa.gov/3d-resources/astronaut/ . Distributed by NASA for educational/informational use under https://www.nasa.gov/nasa-brand-center/images-and-media/ . Draco compression removed; scale normalized. NASA is the resource source, not an endorsement. The source page does not explicitly identify this as CC0; confirm third-party rights before commercial redistribution.
- Earth color map: NASA Blue Marble imagery, mirrored at https://github.com/turban/webgl-earth/blob/master/images/2_no_clouds_4k.jpg . NASA educational/informational media-use guidelines apply. Clouds are a procedural visualization, not a measured meteorological map.
- Moon 01: Poly Haven, https://polyhaven.com/a/moon_01 , CC0: https://polyhaven.com/license . Photoscanned lunar regolith simulant, not a scan captured on the Moon.
- Rocky Terrain 02: Poly Haven, https://polyhaven.com/a/rocky_terrain_02 , CC0: https://polyhaven.com/license . Terrestrial geology used as a visual analogue for Mars.

Rendering uses filtered PCF shadow maps (the current Three.js replaces legacy PCFSoftShadowMap), physically based materials, local image-based lighting and optional N8AO screen-space ambient occlusion. It does not implement hardware ray tracing or physically simulated global illumination.